class ArmstrongCheck {
        n:number;
        message:string;
        checkArmstrong(n:number){
            var temp=0,i=0,length=0,sum=0;
		    var digitArray=new Array(10);
		    temp=n;
		    while(temp>0){
			    digitArray[i++]=temp%10;
			    temp=Math.floor(temp/10);
		    }
		    length=i-1;
		    i=0;
		    for (i = 0; i <= length; i++) 
			sum+=Math.pow(digitArray[i],3);
		    if(sum==n)
			    this.message="The number is an Armstrong Number";
		    else
			    this.message="The number is not an Armstrong Number";
    }
    toString():string{
        return this.message;
    }
}
var armstrongCheck = new ArmstrongCheck();
armstrongCheck.checkArmstrong(371);
console.log(armstrongCheck.toString());
armstrongCheck.checkArmstrong(12);
console.log(armstrongCheck.toString());
