class BinaryToDecimal{
    n:number;
    message:string;
    converyBinaryToDecimal(n:number){
		var i=0,temp=0,length=0,sum=0;
		var arr = new Array(50);
		n=1001;
		temp=n;
		while(temp>0){
			arr[i++]=temp%10;
			temp=Math.floor(temp/10);
		}
		length=i;
		for (i=0;  i<length;  i++) 
			sum+=arr[i]*Math.pow(2,i);
		this.message="The decimal of the number  "+n+" is: "+sum;
    }
    toString():string{
        return this.message;
    }
}
var binary = new BinaryToDecimal();
binary.converyBinaryToDecimal(1001);
console.log(binary.toString());