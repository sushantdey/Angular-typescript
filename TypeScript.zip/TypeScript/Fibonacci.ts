class FibonacciSeries {
    n:number;
    message:string;
    fibonacci(n:number){
		var i=0;
		var array=new Array(10);
		array[0]=0;
		array[1]=1;
		for(i=2;i<=n;i++)
			array[i]=array[i-1]+array[i-2];
		this.message="The Fibnonacci series upto "+n+" is: ";
		for(i=0;i<=n;i++)
			this.message = this.message+array[i]+" ";
	}
    toString():string{
        return this.message;
    }
}
var fibonacciSeries = new FibonacciSeries();
fibonacciSeries.fibonacci(10);
console.log(fibonacciSeries.toString());
