var SwapNumbers = /** @class */ (function () {
    function SwapNumbers(num1, num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    SwapNumbers.prototype.swap = function () {
        this.message = "The value of number 1 is : " + this.num1;
        this.message = this.message + "\nThe value of number 2 is : " + this.num2;
        this.num1 += this.num2;
        this.num2 = this.num1 - this.num2;
        this.num1 -= this.num2;
        this.message = this.message + "\nAfter swapping...";
        this.message = this.message + "\nThe value of number 1 is : " + this.num1;
        this.message = this.message + "\nThe value of number 2 is : " + this.num2;
    };
    SwapNumbers.prototype.toString = function () {
        return this.message;
    };
    return SwapNumbers;
}());
var swap = new SwapNumbers(32, 43);
swap.swap();
