class SwapNumbers {
    num1:number;
    num2:number;
    message:string;
    constructor(num1:number,num2:number){
        this.num1=num1;
        this.num2=num2;
    }
    swap():void{
		this.message="The value of number 1 is : "+this.num1;
		this.message=this.message+"\nThe value of number 2 is : "+this.num2;
		this.num1+=this.num2;
		this.num2=this.num1-this.num2;
		this.num1-=this.num2;
		this.message=this.message+"\nAfter swapping...";
		this.message=this.message+"\nThe value of number 1 is : "+this.num1;
		this.message=this.message+"\nThe value of number 2 is : "+this.num2;
    }
    toString():string{
        return this.message;
    }
}
var swap = new SwapNumbers(32,43);
swap.swap();
console.log(swap.toString());