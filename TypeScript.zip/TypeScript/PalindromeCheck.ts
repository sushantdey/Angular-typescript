class PalindromeSearch {
    n:number;
    message:string;
    palindromeCheck(n:number){
        var i=0;
        var length;
        var array = new Array(10);
        while(n>0){
            array[i++]=n%10;
            n=Math.floor(n/10);
        }
        length=i-1;
        i=0;
        while(i<length-i){
            if(array[i]!=array[length-i]){
                this.message ="Number is not a palindrome";
                return;
            }
            i++;
        }
        if(i>=length-i)
        this.message ="Number is a palindrome";
    }
    toString():string{
        return this.message;
    }
}
var palindrome = new PalindromeSearch();
palindrome.palindromeCheck(121);
console.log(palindrome.toString());