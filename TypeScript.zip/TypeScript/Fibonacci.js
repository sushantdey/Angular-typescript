var FibonacciSeries = /** @class */ (function () {
    function FibonacciSeries() {
    }
    FibonacciSeries.prototype.fibonacci = function (n) {
        var i = 0;
        var array = new Array(10);
        array[0] = 0;
        array[1] = 1;
        for (i = 2; i <= n; i++)
            array[i] = array[i - 1] + array[i - 2];
        this.message = "The Fibnonacci series upto " + n + " is: ";
        for (i = 0; i <= n; i++)
            this.message = this.message + array[i] + " ";
    };
    FibonacciSeries.prototype.toString = function () {
        return this.message;
    };
    return FibonacciSeries;
}());
var fibonacciSeries = new FibonacciSeries();
fibonacciSeries.fibonacci(10);
console.log(fibonacciSeries.toString());
