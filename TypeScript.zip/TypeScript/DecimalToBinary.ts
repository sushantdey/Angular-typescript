class DecimalToBinary {
    n:number;
    message:string;
    convertDecimalToBinary(n:number){
		var i=0,temp=0;
		var arr = new Array(50);
		temp=n;
		while(temp>0){
			arr[i++]=temp%2;
			temp=Math.floor(temp/2);
		}
		this.message="The binary of the number  "+n+" is: ";
		for (i-=1;  i>=0;  i--) 
			this.message=this.message+arr[i];
    }
    toString():string{
        return this.message;
    }
}
var decimal = new DecimalToBinary();
decimal.convertDecimalToBinary(9);
console.log(decimal.toString());